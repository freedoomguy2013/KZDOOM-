This bank was created by Wohlstand from imported instruments from the standard
set of insruments pre-included with GEMS program which was a official Sega
music creation system. Original set was not GM. Therefore, imported instruments
are was organized to provide a proper GM set.

Some instruments was a bit modified, some melodic instruments and percussions
are was taken from Wohlstand's xg.wopn bank.

